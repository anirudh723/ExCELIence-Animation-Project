package cs3500.animator.view;

public class DrawingPanel extends AbstractDrawingPanel {

  public DrawingPanel(){
    super();
  }
}
