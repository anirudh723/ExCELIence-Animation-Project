package cs3500.animator.view;

/**
 * Represents the different types of Views.
 */
public enum ViewType {
  TEXT, VISUAL, SVG
}
