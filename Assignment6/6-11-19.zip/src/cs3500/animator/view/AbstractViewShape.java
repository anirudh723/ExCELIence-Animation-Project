package cs3500.animator.view;

public abstract class AbstractViewShape implements IViewShape {

  @Override
  public void display() {

  }
}
