package cs3500.animator.view;

public class ViewShape implements IViewShape {

  @Override
  public void display() {
    // show the shape here
  }
}
