package cs3500.animator.view;

public interface IViewShape {

  void display();
}
