import org.junit.Before;

/**
 * Testing the implementation for the Animation Model, which will be implemented and tested later.
 */
public class AnimationModelImplTest {

  @Before
  public void setUp() {
    // empty because the implemenation will happen later
  }
}
